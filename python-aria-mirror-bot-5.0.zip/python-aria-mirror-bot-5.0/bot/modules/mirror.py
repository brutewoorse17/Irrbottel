import re
import requests
from telegram.ext import CommandHandler, run_async
from nudenet import NudeClassifier
from bot import Interval, INDEX_URL, LOGGER
from bot import dispatcher, DOWNLOAD_DIR, DOWNLOAD_STATUS_UPDATE_INTERVAL, download_dict, download_dict_lock
from bot.helper.ext_utils import fs_utils, bot_utils
from bot.helper.ext_utils.bot_utils import setInterval
from bot.helper.ext_utils.exceptions import DirectDownloadLinkException, NotSupportedExtractionArchive
from bot.helper.mirror_utils.download_utils.aria2_download import AriaDownloadHelper
from bot.helper.mirror_utils.download_utils.direct_link_generator import direct_link_generator
from bot.helper.mirror_utils.download_utils.telegram_downloader import TelegramDownloadHelper
from bot.helper.mirror_utils.status_utils import listeners
from bot.helper.mirror_utils.status_utils.extract_status import ExtractStatus
from bot.helper.mirror_utils.status_utils.tar_status import TarStatus
from bot.helper.mirror_utils.status_utils.upload_status import UploadStatus
from bot.helper.mirror_utils.upload_utils import gdriveTools
from bot.helper.telegram_helper.bot_commands import BotCommands
from bot.helper.telegram_helper.filters import CustomFilters
from bot.helper.telegram_helper.message_utils import *

# Initialize the NudeClassifier for image analysis
classifier = NudeClassifier()

ariaDlManager = AriaDownloadHelper()
ariaDlManager.start_listener()

# Adult content checks
def check_adult_content_text(link: str) -> bool:
    """
    Check if the link or file name contains adult-related keywords.
    """
    adult_keywords = ['porn', 'xxx', 'sex', 'adult', 'nude', '18+']
    for keyword in adult_keywords:
        if re.search(rf'\b{keyword}\b', link, re.IGNORECASE):
            return True
    return False

def check_adult_content_image(image_path: str) -> bool:
    """
    Check if an image contains adult content using the NudeNet classifier.
    """
    prediction = classifier.classify(image_path)
    return prediction[image_path]['class'] == 'porn'

def check_adult_content_url(link: str) -> bool:
    """
    Check if the URL belongs to a known adult website.
    """
    adult_sites = ['pornhub.com', 'xvideos.com', 'redtube.com', 'xhamster.com']  # Extend this list
    for site in adult_sites:
        if site in link:
            return True
    return False

def check_adult_content(link: str, image_path: str = None) -> bool:
    """
    Combines multiple checks for adult content.
    """
    if check_adult_content_text(link):
        return True
    if image_path and check_adult_content_image(image_path):
        return True
    if check_adult_content_url(link):
        return True
    return False

def editMessage(text: str, bot, message):
    """
    Edit an existing message.
    """
    try:
        bot.editMessageText(chat_id=message.chat_id, message_id=message.message_id, text=text, parse_mode='HTML')
    except Exception as e:
        LOGGER.error(f"Failed to edit message: {e}")

class MirrorListener(listeners.MirrorListeners):
    # Existing MirrorListener code (unchanged for brevity)
    ...

def _mirror(bot, update, isTar=False, extract=False):
    message_args = update.message.text.split(' ')
    try:
        link = message_args[1]
    except IndexError:
        link = ''
    LOGGER.info(link)
    link = link.strip()
    reply_to = update.message.reply_to_message
    image_path = None

    if reply_to is not None:
        file = None
        tag = reply_to.from_user.username
        media_array = [reply_to.document, reply_to.video, reply_to.audio]
        for i in media_array:
            if i is not None:
                file = i
                break

        if len(link) == 0:
            if file is not None:
                if file.mime_type != "application/x-bittorrent":
                    listener = MirrorListener(bot, update, isTar, tag, extract)
                    tg_downloader = TelegramDownloadHelper(listener)
                    tg_downloader.add_download(reply_to, f'{DOWNLOAD_DIR}{listener.uid}/')
                    sendStatusMessage(update, bot)
                    if len(Interval) == 0:
                        Interval.append(setInterval(DOWNLOAD_STATUS_UPDATE_INTERVAL, update_all_messages))
                    return
                else:
                    link = file.get_file().file_path
                    if file.mime_type.startswith('image'):
                        image_path = file.get_file().file_path
    else:
        tag = None

    if not bot_utils.is_url(link) and not bot_utils.is_magnet(link):
        sendMessage('No download source provided', bot, update)
        return

    # Notify the user that the file/link is being checked
    checking_message = sendMessage("Checking the file or link for inappropriate content. Please wait...", bot, update)

    # Check adult content before proceeding with the download
    if check_adult_content(link, image_path):
        # Update the checking message with the result
        editMessage("This content has been flagged as potentially adult content and will not be processed.", bot, checking_message)
        return

    # Update the checking message to notify that the content is safe
    editMessage("The file or link has been checked and found safe. Proceeding with the download...", bot, checking_message)

    try:
        link = direct_link_generator(link)
    except DirectDownloadLinkException as e:
        LOGGER.info(f'{link}: {e}')

    listener = MirrorListener(bot, update, isTar, tag, extract)
    ariaDlManager.add_download(link, f'{DOWNLOAD_DIR}/{listener.uid}/', listener)
    sendStatusMessage(update, bot)
    if len(Interval) == 0:
        Interval.append(setInterval(DOWNLOAD_STATUS_UPDATE_INTERVAL, update_all_messages))

def mirror(update, context):
    _mirror(context.bot, update)

def tar_mirror(update, context):
    _mirror(context.bot, update, True)

def unzip_mirror(update, context):
    _mirror(context.bot, update, extract=True)

mirror_handler = CommandHandler(BotCommands.MirrorCommand, mirror,
                                filters=CustomFilters.authorized_chat | CustomFilters.authorized_user, run_async=True)
tar_mirror_handler = CommandHandler(BotCommands.TarMirrorCommand, tar_mirror,
                                    filters=CustomFilters.authorized_chat | CustomFilters.authorized_user, run_async=True)
unzip_mirror_handler = CommandHandler(BotCommands.UnzipMirrorCommand, unzip_mirror,
                                      filters=CustomFilters.authorized_chat | CustomFilters.authorized_user, run_async=True)
dispatcher.add_handler(mirror_handler)
dispatcher.add_handler(tar_mirror_handler)
dispatcher.add_handler(unzip_mirror_handler)